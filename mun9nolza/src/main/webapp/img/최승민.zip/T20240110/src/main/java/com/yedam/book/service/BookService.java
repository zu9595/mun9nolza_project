package com.yedam.book.service;

import java.util.List;

import com.yedam.book.vo.BookVO;

public interface BookService {
	List<BookVO> bookList();
}
